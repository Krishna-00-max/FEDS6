# Login and Registration Form — React State

## Run in VS Code
Install Node.js (22 LTS recommended). Open this project folder in VS Code and run:

```sh
npm install
npm run dev
```
Open the local URL shown in the terminal (usually http://localhost:5173).

## Demo
1. Register using a fictional name, email and password of at least six characters.
2. The registered name and email appear below the registration form.
3. Login using the same email and password: Login successful.
4. Try an incorrect password: Error: Invalid email or password.
5. Refresh and try login without registration: Error: Please register first.

## Concept
React useState manages controlled inputs, the registered account, and feedback messages. onChange updates state; onSubmit prevents page reload, validates and updates state. Conditional rendering displays details and success/error messages.

This is a frontend-only learning demo, not production authentication. One account is held in memory; registering again replaces it. Passwords are not displayed. Do not use real credentials. Refresh clears all state. A real application needs a backend and secure password hashing.

## Build
`npm run build` creates the production bundle in dist. Dependencies are not bundled in this ZIP; npm install downloads them.
