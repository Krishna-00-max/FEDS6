import React, { useState } from "react";

export default function App() {
  const [registration, setRegistration] = useState({
    name: "",
    email: "",
    password: "",
  });
  const [account, setAccount] = useState(null);
  const [login, setLogin] = useState({ email: "", password: "" });
  const [registrationMessage, setRegistrationMessage] = useState("");
  const [loginMessage, setLoginMessage] = useState("");
  const [success, setSuccess] = useState(false);

  function register(event) {
    event.preventDefault();

    if (
      !registration.name.trim() ||
      !registration.email.trim() ||
      registration.password.length < 6
    ) {
      setRegistrationMessage(
        "Enter a name, email and a password of at least 6 characters."
      );
      return;
    }

    setAccount({
      name: registration.name.trim(),
      email: registration.email.trim().toLowerCase(),
      password: registration.password,
    });
    setRegistrationMessage("Registration successful!");
    setRegistration({ name: "", email: "", password: "" });
    setLogin({ email: "", password: "" });
    setLoginMessage("");
    setSuccess(false);
  }

  function signIn(event) {
    event.preventDefault();

    const valid =
      account !== null &&
      login.email.trim().toLowerCase() === account.email &&
      login.password === account.password;

    setSuccess(valid);
    setLoginMessage(
      valid
        ? "Login successful"
        : account
          ? "Error: Invalid email or password."
          : "Error: Please register first."
    );
    setLogin((current) => ({ ...current, password: "" }));
  }

  return (
    <main>
      <header>
        <p className="eyebrow">REACT STATE • FORM DEMO</p>
        <h1>Login &amp; Registration</h1>
        <p>Create an account and log in using the same credentials.</p>
      </header>

      <div className="layout">
        <section className="panel">
          <h2>Registration</h2>
          <form onSubmit={register}>
            <label htmlFor="name">Full name</label>
            <input
              id="name"
              value={registration.name}
              onChange={(event) =>
                setRegistration({
                  ...registration,
                  name: event.target.value,
                })
              }
              placeholder="Enter your name"
              required
            />

            <label htmlFor="reg-email">Email</label>
            <input
              id="reg-email"
              type="email"
              value={registration.email}
              onChange={(event) =>
                setRegistration({
                  ...registration,
                  email: event.target.value,
                })
              }
              placeholder="name@example.com"
              required
            />

            <label htmlFor="reg-password">Password</label>
            <input
              id="reg-password"
              type="password"
              value={registration.password}
              onChange={(event) =>
                setRegistration({
                  ...registration,
                  password: event.target.value,
                })
              }
              placeholder="At least 6 characters"
              minLength={6}
              autoComplete="new-password"
              required
            />

            <button>Register</button>
          </form>

          {registrationMessage && (
            <p
              role="status"
              className={
                registrationMessage.startsWith("Registration successful")
                  ? "success"
                  : "error"
              }
            >
              {registrationMessage}
            </p>
          )}

          {account && (
            <div className="details">
              <h3>Registered details</h3>
              <p>
                <strong>Name:</strong> {account.name}
              </p>
              <p>
                <strong>Email:</strong> {account.email}
              </p>
              <p>
                <strong>Password:</strong> Hidden for privacy
              </p>
            </div>
          )}
        </section>

        <section className="panel">
          <h2>Login</h2>
          <form onSubmit={signIn}>
            <label htmlFor="login-email">Email</label>
            <input
              id="login-email"
              type="email"
              value={login.email}
              onChange={(event) =>
                setLogin({ ...login, email: event.target.value })
              }
              placeholder="name@example.com"
              required
            />

            <label htmlFor="login-password">Password</label>
            <input
              id="login-password"
              type="password"
              value={login.password}
              onChange={(event) =>
                setLogin({ ...login, password: event.target.value })
              }
              placeholder="Enter your password"
              autoComplete="current-password"
              required
            />

            <button>Login</button>
          </form>

          {loginMessage && (
            <p role="status" className={success ? "success" : "error"}>
              {loginMessage}
            </p>
          )}
        </section>
      </div>

      <footer>
        Educational demo only. Use fictional credentials. State resets when the
        page is refreshed.
      </footer>
    </main>
  );
}
